package com.example.authenticationconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticationConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
